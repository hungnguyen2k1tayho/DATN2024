package com.example.Quanlysukien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanlysukienApplicationTests {

	@Test
	void contextLoads() {
	}

}
